<?php

// Tambahkan di awal blast.php setelah session_start() jika perlu
session_start();

// Cek jika akses manual via browser
if (isset($_GET['manual']) && $_GET['manual'] == '1') {
    // Cek apakah user adalah admin/staff
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
        die("Akses ditolak. Hanya admin/staff yang dapat mengirim manual.");
    }
    
    // Tampilkan header HTML untuk manual execution
    echo "<!DOCTYPE html><html><head><title>Blast Manual</title></head><body>";
    echo "<h2>Mengirim Blast WhatsApp Manual</h2>";
    echo "<pre>";
}

// Set zona waktu agar deteksi hari sesuai dengan lokasi Anda
date_default_timezone_set('Asia/Jakarta');

require_once 'wa.php'; 

// Cek keberadaan file setting
if (!file_exists('blast_settings.json')) {
    die("Error: File blast_settings.json tidak ditemukan.");
}

$settings = json_decode(file_get_contents('blast_settings.json'), true);

// 1. Cek apakah status sedang aktif
if ($settings['status'] !== 'aktif') {
    die("Blast dibatalkan: Status saat ini sedang Libur/Nonaktif.");
}

// 2. Koneksi Database - GUNAKAN MySQLi KONSISTEN
$host = 'localhost';
$db   = 'quic1934_absensi_online';
$user = 'quic1934_Admin123'; 
$pass = '.A7991h80d70.';     
$charset = 'utf8mb4';

// Membuat koneksi MySQLi
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
$conn->set_charset($charset);

// 3. Mapping Hari Indonesia
$hari_inggris = date('l');
$map_hari = [
    'Monday'    => 'Senin',
    'Tuesday'   => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday'  => 'Kamis',
    'Friday'    => 'Jumat',
    'Saturday'  => 'Sabtu',
    'Sunday'    => 'Ahad'
];
$hari_ini = $map_hari[$hari_inggris];
$tanggal_sekarang = date('Y-m-d');

// 4. Ambil Jadwal Hari Ini untuk SEMUA jenis (Madin, Quran, Kegiatan)
$jadwal_list = [];

// Jadwal Madin
$sql_madin = "SELECT jm.jadwal_id, jm.kelas_madin_id, km.nama_kelas, g.nama, g.no_hp, 'madin' as jenis
              FROM jadwal_madin jm
              JOIN guru g ON jm.guru_id = g.guru_id
              JOIN kelas_madin km ON jm.kelas_madin_id = km.kelas_id
              WHERE jm.hari = ?";
$stmt_madin = $conn->prepare($sql_madin);
$stmt_madin->bind_param("s", $hari_ini);
$stmt_madin->execute();
$result_madin = $stmt_madin->get_result();
while ($row = $result_madin->fetch_assoc()) {
    $jadwal_list[] = $row;
}

// Jadwal Quran (jika ada tabelnya)
$sql_quran = "SELECT jq.id as jadwal_id, jq.kelas_quran_id as kelas_id, 
                     kq.nama_kelas, g.nama, g.no_hp, 'quran' as jenis
              FROM jadwal_quran jq
              JOIN guru g ON jq.guru_id = g.guru_id
              JOIN kelas_quran kq ON jq.kelas_quran_id = kq.id
              WHERE jq.hari = ?";
$stmt_quran = $conn->prepare($sql_quran);
$stmt_quran->bind_param("s", $hari_ini);
$stmt_quran->execute();
$result_quran = $stmt_quran->get_result();
while ($row = $result_quran->fetch_assoc()) {
    $jadwal_list[] = $row;
}

if (empty($jadwal_list)) {
    echo "Tidak ada jadwal mengajar untuk hari $hari_ini.";
    exit;
}

// 5. Proses Blast untuk semua jadwal
foreach ($jadwal_list as $row) {
    $nama_guru = $row['nama'];
    $no_hp = trim($row['no_hp']);
    $nama_kelas = $row['nama_kelas'];
    $jenis = $row['jenis'];
    $kelas_id_field = ($jenis == 'madin') ? 'kelas_madin_id' : 'kelas_id';
    
    // Validasi dan format nomor HP
    if (empty($no_hp)) {
        echo "Skip: $nama_guru tidak memiliki nomor HP.\n";
        continue;
    }
    
    // Format nomor HP: jika dimulai dengan 0, ganti dengan 62
    if (substr($no_hp, 0, 1) == '0') {
        $no_hp = '62' . substr($no_hp, 1);
    }
    
    // Susun Link Absensi berdasarkan jenis jadwal
    $link_absen = "";
    if ($jenis == 'madin') {
        $link_absen = "http://absen.quizb.my.id/pages/absensi.php?active_tab=pelajaran&filter=1&tanggal=$tanggal_sekarang&kelas_id={$row[$kelas_id_field]}&jadwal_id={$row['jadwal_id']}";
    } elseif ($jenis == 'quran') {
        $link_absen = "http://absen.quizb.my.id/pages/absensi.php?active_tab=quran&filter_quran=1&tanggal_quran=$tanggal_sekarang&kelas_quran_id={$row[$kelas_id_field]}&jadwal_quran_id={$row['jadwal_id']}";
    }

    // Replace Placeholder di Template
    $pesan = str_replace(
        ['{{nama}}', '{{kelas}}', '{{link}}'],
        [$nama_guru, $nama_kelas, $link_absen],
        $settings['template']
    );

    // Kirim via WA
    $hasil = kirimWA($no_hp, $pesan);
    echo "Terkirim ke: $nama_guru ($no_hp) - $jenis - $nama_kelas | Status: $hasil\n";
    
    // Delay antar pengiriman untuk menghindari spam
    sleep(2);
}

$conn->close();
?>