<?php
// cron_test.php
date_default_timezone_set('Asia/Jakarta');
$log_file = 'cron_test_log.txt';
$message = "Cron job berjalan pada: " . date('Y-m-d H:i:s') . "\n";
file_put_contents($log_file, $message, FILE_APPEND);
echo $message;
?>